$(document).ready(function() {
  $.browser = {};
(function () {
    $.browser.msie = false;
    $.browser.version = 0;
    if (navigator.userAgent.match(/MSIE ([0-9]+)\./)) {
        $.browser.msie = true;
        $.browser.version = RegExp.$1;
    }
})();
    $('.footer-column .column:first').addClass('quicklinks');
    $('.owl-carousel').owlCarousel({
      loop:true,
      margin:0,
      nav:true,
      responsive:{
          420:{
              items:2
          },
          600:{
              items:4
          },
          1000:{
              items:6
          }
      }
  	});
  $('#horizontalTab').easyResponsiveTabs({
        type: 'default', //Types: default, vertical, accordion           
        width: 'auto', //auto or any width like 600px
        fit: true,   // 100% fit in a container
        closed: 'accordion', // Start closed if in accordion view
        activate: function(event) { // Callback function if tab is switched
            var tab = $(this);
            var info = $('#tabInfo');
            var name = $('span', info);

            name.text(tab.text());

            info.show();
        }		
    });
  $('.slider').slick({
 	slidesToShow: 1,
 	slidesToScroll: 1,
 	arrows: true,
 	fade: false,
 	asNavFor: '.slider-nav-thumbnails',
 });

 $('.slider-nav-thumbnails').slick({
 	slidesToShow: 5,
 	slidesToScroll: 1,
 	asNavFor: '.slider',
 	dots: false,
 	focusOnSelect: true
 });
  $('.popular-product h3').click(function() {
  	$('.popular-product .popular-menu').slideToggle();
    $('.popular-product').toggleClass('active');
  });
  $('.menu-cms .block-title h2').click(function() {
  	$('.menu-cms .block-content').slideToggle();
  });
  $('.icon-search').click(function() {
    $('.header-top-center').toggleClass('active');
  	$('.header-search').slideToggle();
  });
  $('.header-search label.icon').click(function() {
    $('.header-top-center').removeClass('active');
  	$('.header-search').hide();
  });
  $('.icon-menu').click(function() {
  	$('.menu-mobile').slideToggle();
  });
  $('.icon-close').click(function() {
  	$('.menu-mobile').hide();
  });
  var swiper = new Swiper('.swiper-container', {
      slidesPerView: 2,
      slidesPerColumn: 2,
      spaceBetween: 30,
      navigation: {
        nextEl: '.swiper-button-next',
        prevEl: '.swiper-button-prev',
      },
    });
  
  var swiper = new Swiper('.swiper-containers', {
      slidesPerView: 2,
      slidesPerColumn: 2,
      spaceBetween: 30,
      navigation: {
        nextEl: '.swiper-button-next',
        prevEl: '.swiper-button-prev',
      },
    });
  
  $('.fancybox').fancybox();
  	
});